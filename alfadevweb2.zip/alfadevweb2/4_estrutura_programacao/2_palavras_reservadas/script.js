//3nome ='jeferson';

nome3 = "jeferson";
$sobrenome = "tosti";

_idade = 19;

console.log(nome3 + $sobrenome + _idade);