nome= "jeferson";
console.log(nome);

console.log(`o meu nome é ${nome}`); //LITERALS
console.log("o meu nome é ${nome}"); // ASPAS DUPLAS 
console.log('o meu nome é ${nome}'); // ASPAS SIMPLES 

let laranja = 5;

console.log(laranja + laranja);

let cerveja = 2;
var refrigerante = 3;
const agua = 4;

//agua = 3; nao pode ser alterado pelo const

console.log(refrigerante);