nome = prompt('qual seu nome?');

idade = prompt("qual sua idade meu irmao?");

console.log('sua idade é ' + idade);

console.log('Olá ' + nome + ' sua idade é ' + idade);