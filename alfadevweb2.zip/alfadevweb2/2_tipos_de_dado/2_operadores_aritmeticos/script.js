console.log(2 + 3);
console.log(19 - 8);
console.log(2 * 8);
console.log(212 / 8);

console.log(21 % 2);

console.log(120 % 12);

console.log(typeof(2 + 3));
console.log(typeof(19 - 8));
console.log(typeof(2 * 8));