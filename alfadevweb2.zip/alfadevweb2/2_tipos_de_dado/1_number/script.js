console.log(typeof 5);
console.log(typeof 20.8);
console.log(typeof "VulgoJefin");
console.log(typeof true);
console.log(typeof false);