console.log("Meu nome é VulgoJefin");
console.log('Sou Estudante');
console.log(`Isso é um teste`);

console.log(typeof "Meu nome é VulgoJefin");
