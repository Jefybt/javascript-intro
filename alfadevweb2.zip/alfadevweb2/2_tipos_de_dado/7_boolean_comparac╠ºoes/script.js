console.log(1 > 2);
console.log(1 < 2);
console.log(1 >= 2);
console.log(1 <= 2);

console.log('Jeferson' != "alan");
console.log(3 == `3`);
console.log(3 === `3`);
console.log(3 === 3);