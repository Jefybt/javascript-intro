console.log(2 + 2);
console.log(2 - 2);
console.log(2 * 2);
console.log(2 / 2);
console.log(2 % 2);

console.log(typeof(2 + 3));
console.log(typeof (5 - 3));

