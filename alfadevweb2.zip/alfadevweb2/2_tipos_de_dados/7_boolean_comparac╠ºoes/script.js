console.log(5 > 3 && 3 == 2);
console.log(5 > 3 || 3 == 2);
console.log(!(5 > 3 || 3 == 2));
console.log(3 === '3' && "alan" == "ALAN");
console.log(!(true && true));



