console.log("oi meu nome é?");
console.log('Sou estudante');
console.log(`Isso é um teste`);

