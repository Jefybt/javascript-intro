maior = Math.max(90,98,115,54,12,9,27,23);
console.log(maior);

menor = Math.min(9,98,115,54,40);
console.log(menor);

arredonda = Math.ceil(6.900);
console.log(arredonda);

aleatorio = Math.random();
console.log(aleatorio);

//aleatorio = Math.ceil(aleatorio);
//console.log(aleatorio);