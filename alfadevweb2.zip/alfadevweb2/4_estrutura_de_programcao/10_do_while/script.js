x = 100;
do {
    console.log(x);
    x--;
} while (x >= 0);
console.log('<hr>');
x = 100;
while (x >= 0) {
    console.log(x);
    x--;
}