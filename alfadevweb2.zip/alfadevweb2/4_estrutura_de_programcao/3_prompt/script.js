idade = prompt("Qual sua idade parceiro?");
console.log("Sua idade é " + idade);

nome = prompt("Qual seu nome campeão?");
console.log('Olá' + nome + "sua idade é " + idade);






