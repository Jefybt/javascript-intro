x = 10;
while(x > 0){
    console.log(' O valor de x é ' + x);
        x =  x -1;
}
while( x <= 10){
    console.log('O valor é ' + x);
    x--;
}