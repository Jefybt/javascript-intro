idade = 40;

//se 
if(idade == 19){
    console.log('Você nao pode beber');
}
if(idade >= 18){
    console.log('Você pode dirigir!');
}

usuario = "jeferson";
senha = 'jefin123';
if((usuario == "jeferson") && (senha == "jefin123")){
    console.log('Acesso liberado!');
    alert('Bem Vindo ' + usuario);
}

console.log(usuario == "jeferrrson") //boolean