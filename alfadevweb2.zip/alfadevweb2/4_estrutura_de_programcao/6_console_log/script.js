idade = 28;
nome = "jeferson";

console.log(`Meu nome é ${nome}, tenho ${idade} anos`);
console.log('Meu nome é ' + nome + ', tenho ' + idade + ' anos');