//3nome='alan';
nome3='alan ';
$sobrenome = 'reis ';
_idade = 15;
console.log(nome3 + $sobrenome + _idade);







