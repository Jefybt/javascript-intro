velocidade = 45;

if( velocidade <= 40){
    console.log('parabens');
}else if((velocidade > 40) && (velocidade < 45)) {
    console.log('atenção');
} else{
    console.log('Perigo!!!');
}
