nome = "Alan";
console.log(nome);

console.log(`O meu nome é ${nome}`);
console.log("O meu nome é ${nome}");
console.log('O meu nome é ${nome}');

//"" e '' reconhece o códgico como uma string já os ` não//


let laranjas = 5;
console.log(laranjas * laranjas);

let cerveja = 2;
var refrigerante = 3;
const agua = 4;

// const não poder ser alterado

console.log(cerveja);






