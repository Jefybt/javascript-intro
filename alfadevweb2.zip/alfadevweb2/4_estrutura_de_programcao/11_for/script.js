//for (inicializacao) (condicao) (expressao final)
for (i = 0; i < 100; i = i + 2) {
    console.log(`A Soma de i com 2 é ${i + 2} `);
}