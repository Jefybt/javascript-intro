console.log( 25);
console.log( 75.9);
console.log( 75 + 25);
console.log(typeof (20 + 15));