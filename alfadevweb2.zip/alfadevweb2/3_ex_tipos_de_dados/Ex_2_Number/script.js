console.log(06);
console.log(10,5);
console.log((2 / 2));







