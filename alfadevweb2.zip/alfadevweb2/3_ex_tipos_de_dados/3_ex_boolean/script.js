console.log(25 > 49);
console.log(73 <= 80);
console.log(25 != 25);