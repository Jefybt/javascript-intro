console.log(4>2);
console.log(10<=10);
console.log(9!=10);

console.log(typeof(4>2));
console.log(typeof(10<=10));
console.log(typeof(9!=10));







