console.log(9>8 && 19==9);
console.log(9>8 || 9==9);
console.log(!(9>8 || 19==9));








