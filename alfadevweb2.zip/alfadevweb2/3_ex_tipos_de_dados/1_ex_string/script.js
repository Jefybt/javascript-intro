console.log("Aspas Duplas");
console.log('Aspas Simples');
console.log(`literals`);