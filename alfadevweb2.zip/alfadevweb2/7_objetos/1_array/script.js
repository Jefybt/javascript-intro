numero = [1,2,3,4,5,6];
nome = ["joao", "marcos", "jefin"];
booleanos = [true,false,true];