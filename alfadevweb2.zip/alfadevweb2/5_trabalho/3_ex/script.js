name = "joão";
idade = 18;
homem = true;
console.log(typeof(nome));
console.log(typeof(idade));
console.log(typeof(homem));