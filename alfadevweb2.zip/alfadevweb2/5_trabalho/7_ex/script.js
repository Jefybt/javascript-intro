for(let x = 0; x >= 00; x--){
    console.log(x);
}