divisao = 0;

numero = prompt("insia um numero");
for(x = numero; x > 0; x--){
    if(numero % x == 0){
        divisao++;
    }
}
if(divisao == 2){
    console.log(divisao + "_ o numero " + numero + " é um numero primo")
} else{
    console.log(divisao + "_ o numero " + numero + " Nao é um numero primo")
}