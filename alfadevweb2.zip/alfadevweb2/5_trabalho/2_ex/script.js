const name = "jefin";
if(nome == "jefin"){
    console.log("Bem-Vindo")
    alert("Seja Bem Vindo" + nome);
}
