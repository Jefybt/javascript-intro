valor = 0;
while(valor <= 20){
    console.log(valor);
    valor++;
}