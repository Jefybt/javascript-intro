cnh = true;
idade = 6;

if(idade >= 18 && cnh == true){
    console.log("Voce pode dirigir");
} else if(idade <= 18 || cnh == false){
    console.log("Voce nao pode dirigir");
}