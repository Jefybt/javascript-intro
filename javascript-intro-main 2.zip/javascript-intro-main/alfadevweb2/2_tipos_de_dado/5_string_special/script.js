console.log("primeira linha \n segunda linha");

console.log(`a multiplicação de
 5 por 3 é ${5*3}`);