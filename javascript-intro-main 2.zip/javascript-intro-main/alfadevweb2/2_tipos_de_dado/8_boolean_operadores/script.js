console.log(5 > 3 && 3 == 2);

console.log(5 > 3 || 3 == 2);

console.log(!(5 > 3 || 3 == 2));//! negação

console.log(3 === 3 && "alan" == "ALAN");

console.log(true && false);

console.log(!(true && true));