console.log("1234" + 5);
console.log(typeof("1234" + 5));
console.log('1234' - 5);

console.log(typeof('1234' - 5));


console.log('1234' * 5);

console.log("oi" * 5);