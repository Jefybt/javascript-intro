/*
6_exercicio
Escreva um loop while que exibe números um a um, 
indo de 0 a 20 no console;*/
valor = 0;
while(valor <= 20){
    console.log(valor);
    valor++;
}