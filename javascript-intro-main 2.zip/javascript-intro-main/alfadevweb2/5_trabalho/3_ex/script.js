/*
3_exercicio
Armazene valores em variáveis 
com cada um dos tipos de dados
 vistos; String, Number e Boolean;
*/
nome = "João";
idade = 18;
homem = true;

console.log(typeof(nome));
console.log(typeof(idade));
console.log(typeof(homem));

