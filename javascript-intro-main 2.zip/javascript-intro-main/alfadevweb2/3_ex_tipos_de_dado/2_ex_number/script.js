/*Escreva três valores em number
Com números inteiros, 
números com casa decimal
 e por operação aritmética;*/
console.log(100);
console.log(99.90);
console.log(99-1);
console.log(typeof(99-1));