//objeto
cachorro = {
    //propriedades
    cor: 'branco',
    patas: 4,
    nome: 'flavin',

    //metodo
    latir: function(){
        console.log('miau');
    }
}
cachorro.latir();
console.log(cachorro.cor);
console.log(cachorro.patas);
console.log(cachorro.nome);

//array usa []

