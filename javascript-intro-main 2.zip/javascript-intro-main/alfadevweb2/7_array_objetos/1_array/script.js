numero = [1,2,3,4,5,6];
nome=['joão', 'Marcos','Denicreidsson'];
booleanos=[true,false,true];

console.log(numero);

console.log(nome);

console.log(booleanos);
