nomes = ['flavin', 'dorisvaldo',];

elementRemovido = nomes.pop();

console.log(elementoRemovido);

console.log(nomes);

nomes.push('Tiao');

console.log(nomes);