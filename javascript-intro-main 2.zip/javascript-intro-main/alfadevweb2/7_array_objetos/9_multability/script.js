//multabilidade altera um obj e altera todos
pessoa = {
    nome: 'paulo'
}
pessoa2 = pessoa;
console.log(pessoa.nome);
console.log(pessoa2.nome);

pessoa2.nome='ju';
console.log(pessoa.nome);
console.log(pessoa2.nome);

pessoa2.nome='joao';
console.log(pessoa.nome);
console.log(pessoa2.nome);

pessoa3={
    nome:'jorge'
}

console.log(pessoa3.nome);
pessoa3 = pessoa

console.log(pessoa3.nome);

