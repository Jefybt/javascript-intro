nome = ['biruleibe', 'pixuruca', 'Josémaria', 'Mariajosé']

nome.forEach( x => {
    console.log('bons estudos' + x);
});
