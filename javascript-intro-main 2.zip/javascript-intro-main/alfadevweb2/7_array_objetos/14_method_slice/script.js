num = [5,6,7,8,4,4,4];

console.log(num.slice(4,5));
//tras a posicao 4 pq para uma posicao antes


console.log(num.slice(4,6));
//tras apartir da posicao

console.log(num.slice(-2));
//pega apenas os 2 ultimo

console.log(num.slice(1,-2));
//pega de um e deixa os dois ultimos fora
