nomes = ['flavin', 'dorisvaldo',];

console.log(nomes.shift());

console.log(nomes);

nomes.unshift('izabel', 'rip');

console.log(nomes);