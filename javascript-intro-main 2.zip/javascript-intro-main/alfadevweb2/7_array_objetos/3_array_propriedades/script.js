numero = [1,2,3,4,5,6];
nome=['joão', 'Marcos','Denicreidsson'];
booleanos=[true,false,true];

console.log(nome.lenght);
//conta os valores atribuidos
estudante = "Denicreidsson";
console.log(estudante.lenght);

function teste($0,$1,$2,$3, $valor = null){

}
console.log(teste.length);
