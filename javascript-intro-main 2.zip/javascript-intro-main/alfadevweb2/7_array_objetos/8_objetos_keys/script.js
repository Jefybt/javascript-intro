// key é o nome da propriedade do obj
obj = {
    'chave1': 1,
    'chave1': 2,
    'chave1': 3
}
console.log(obj);

console.log(object.keys(obj));