//for([inicializacao]; [condicao]; [expressao final]){
//declaracao
//}
nomes = ['jubileu', 'osvaldino', 'flavin'];

for (let i = 0; i < nomes.length; i++) {
    console.log(nomes[i]);
}